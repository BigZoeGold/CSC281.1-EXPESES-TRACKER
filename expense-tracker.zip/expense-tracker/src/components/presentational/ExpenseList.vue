<script setup>
// 1. Define the 'delete' event so the parent can hear it
const emit = defineEmits(['delete-expense']);

defineProps({
  expenses: {
    type: Array,
    required: true
  }
})

// 2. Function to send the ID upwards
const confirmDelete = (id) => {
  emit('delete-expense', id);
};
</script>

<template>
  <div class="expense-list">
    <table v-if="expenses.length > 0">
      <thead>
        <tr>
          <th>Date</th>
          <th>Description</th>
          <th>Category</th>
          <th>Amount</th>
          <th>Action</th> </tr>
      </thead>
      <tbody>
        <tr v-for="item in expenses" :key="item.id">
          <td>{{ item.date }}</td>
          <td>{{ item.description }}</td>
          <td>{{ item.category }}</td>
          <td>${{ item.amount }}</td>
          <td>
            <button @click="confirmDelete(item.id)" class="delete-btn">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
    <p v-else>No expenses found.</p>
  </div>
</template>

<style scoped>
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
th, td {
  padding: 12px;
  border-bottom: 1px solid #444;
  text-align: left;
}
th {
  color: #42b883;
}
/* Style for the delete button */
.delete-btn {
  background-color: #ff4d4d;
  color: white;
  border: none;
  padding: 5px 10px;
  border-radius: 4px;
  cursor: pointer;
}
.delete-btn:hover {
  background-color: #cc0000;
}
</style>