<script setup>
import { expenseService } from '../services/expenseStorage.js';
import ExpenseList from './presentational/ExpenseList.vue';
import ExpenseForm from './presentational/ExpenseForm.vue';

const handleAddExpense = (newExpense) => {
  expenseService.expenses.push(newExpense);
};

// 1. New function to remove the expense by its ID
const handleDeleteExpense = (id) => {
  // We filter the array to keep everything EXCEPT the item with this ID
  expenseService.expenses = expenseService.expenses.filter(item => item.id !== id);
};
</script>

<template>
  <div class="expense-container">
    <h1>My Expense Tracker</h1>
    
    <ExpenseForm @create-expense="handleAddExpense" />

    <ExpenseList 
      :expenses="expenseService.expenses" 
      @delete-expense="handleDeleteExpense" 
    />
  </div>
</template>

<style scoped>
.expense-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}
h1 {
  text-align: center;
  color: white;
  margin-bottom: 30px;
}
</style>