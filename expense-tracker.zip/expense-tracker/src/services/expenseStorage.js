import { reactive } from 'vue';

// We use 'export const' so we can import it with curly braces { }
export const expenseService = reactive({
  expenses: [
    {
      id: 1,
      description: 'Lunch',
      amount: 15.50,
      category: 'Food',
      date: '2026-02-05'
    },
    {
      id: 2,
      description: 'Bus Fare',
      amount: 2.75,
      category: 'Transport',
      date: '2026-02-05'
    }
  ]
});